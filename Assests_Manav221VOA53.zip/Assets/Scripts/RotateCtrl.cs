using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateCtrl : MonoBehaviour
{
    //this variable is used for attaching the game object
    public GameObject planetObject;
    public Vector3 RotationVector;

    void Update()
    {
        planetObject.transform.Rotate(RotationVector * Time.deltaTime);
    }
}
